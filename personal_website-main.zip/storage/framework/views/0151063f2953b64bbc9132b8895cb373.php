<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    
    <?php if(!isset($seo)): ?>
        <?php echo $__env->make('frontend.layouts.includes.meta', [
            'seo' => (object) [
                'title' => 'Md Shefat Masum',
            ],
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php else: ?>
        <?php echo $__env->make('frontend.layouts.includes.meta', ['seo' => (object) $seo], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    <link rel="fabicon" type="image/png" sizes="16x16" href="<?php echo e(asset('/cache/favicon.ico')); ?>">
    <link rel="stylesheet" href="/cache/assets/website/assets/css/plugins/bootstrap.min.css">
    <link rel="stylesheet" href="/cache/assets/website/assets/css/style.css">
    <link rel="stylesheet" href="/cache/assets/website/assets/css/custom.css">

</head>

<body>
    <?php if(env('APP_ENV') != 'local'): ?>
        <!-- Google Tag Manager (noscript) -->
        <noscript>
            <iframe src="https://www.googletagmanager.com/ns.html?id=GTM-P9MCWSJ7" height="0" width="0"
                style="display:none;visibility:hidden"></iframe>
        </noscript>
        <!-- End Google Tag Manager (noscript) -->
    <?php endif; ?>

    
    <span class="cs_cursor_lg d"></span>
    <span class="cs_cursor_sm"></span>

    <header class="cs_site_header cs_style_1 cs_sticky_header">
        <div class="cs_main_header">
            <div class="container">
                <div class="cs_main_header_in">
                    <div class="cs_main_header_left">
                        <a class="cs_site_branding" href="/">
                            <img src="/cache/assets/website/assets/img/logo.png" height="76px" width="86px"
                                alt="Logo">
                        </a>
                    </div>
                    <div class="cs_main_header_center">
                        <?php echo $__env->make('frontend.layouts.includes.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="cs_main_header_right">
                        <a href="/contact" class="cs_btn cs_style_1 cs_primary_font">
                            <span>Hire Me</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <!-- End Header Section -->

    <!-- Main content inside start-->
    <main>
        <?php echo $__env->yieldContent('contents'); ?>
    </main>
    <!-- Main content inside end-->

    <!-- Start Footer -->
    <footer class="cs_footer cs_style_1 cs_filled_bg position-relative">
        <div class="position-absolute cs_footer_shape_1">
            <img src="/cache/assets/website/assets/img/footer_shape.svg" alt="">
        </div>
        <div class="container">
            <div class="cs_footer_cta">
                <h2 class="cs_font_92 cs_gradient_text_2 cs_semi_bold">Have a project?</h2>
                <a href="contact.html" class="cs_btn cs_style_1 cs_primary_font"><span>Let’s
                        Talk</span></a>
            </div>
            <div class="cs_copyright">© 2023 <a href="#">Laralink</a>. All rights reserved</div>
        </div>
    </footer>
    <!-- End Footer -->

    <!-- Start video popup -->
    
    <!-- End video popup -->

    

    <link rel="stylesheet" href="/cache/assets/website/assets/css/plugins/fontawesome.min.css">
    <link rel="stylesheet" href="/cache/assets/website/assets/css/plugins/odometer-theme-default.css">
    <link rel="stylesheet" href="/cache/assets/website/assets/css/plugins/animate.css">


    <script src="<?php echo e(asset('/cache/assets/website/assets/js/plugins/jquery-3.6.0.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/cache/assets/js/plugins/localforage.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/cache/assets/js/plugins/sweetalert.js')); ?>"></script>
    <script src="<?php echo e(asset('/cache/assets/js/plugins/axios.js')); ?>"></script>
    <script src="<?php echo e(asset('/cache/assets/website/assets/js/plugins/gsap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/cache/assets/website/assets/js/plugins/odometer.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/cache/assets/website/assets/js/main.js')); ?>"></script>
    <script src="<?php echo e(asset('/cache/assets/js/frontend.js')); ?>"></script>

    <?php if(env('APP_ENV') != 'local'): ?>
        <!-- Google tag (gtag.js) -->
        <script async src="https://www.googletagmanager.com/gtag/js?id=G-YN023B9MCX"></script>
        <script>
            window.dataLayer = window.dataLayer || [];

            function gtag() {
                dataLayer.push(arguments);
            }
            gtag('js', new Date());

            gtag('config', 'G-YN023B9MCX');
        </script>
        <!-- Google Tag Manager -->
        <script>
            (function(w, d, s, l, i) {
                w[l] = w[l] || [];
                w[l].push({
                    'gtm.start': new Date().getTime(),
                    event: 'gtm.js'
                });
                var f = d.getElementsByTagName(s)[0],
                    j = d.createElement(s),
                    dl = l != 'dataLayer' ? '&l=' + l : '';
                j.async = true;
                j.src =
                    'https://www.googletagmanager.com/gtm.js?id=' + i + dl;
                f.parentNode.insertBefore(j, f);
            })(window, document, 'script', 'dataLayer', 'GTM-P9MCWSJ7');
        </script>
        <!-- End Google Tag Manager -->
    <?php endif; ?>
</body>

</html>
<?php /**PATH F:\workspace\siyam\personal_website-main\resources\views/frontend/layouts/layout.blade.php ENDPATH**/ ?>