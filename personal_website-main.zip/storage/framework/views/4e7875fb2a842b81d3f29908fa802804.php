    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e($meta->fabicon ?? asset('favicon.ico')); ?>">

    <meta name="robots" content="index, follow">
    <!-- <meta http-equiv="refresh" content="5"> -->
    <?php
        $des = "
            Hi I am Shefat, a dedicated software engineer passionate about crafting efficient,
            innovative solutions for complex challenges in the tech industry.
        ";
    ?>

    <meta name="logo" content="<?php echo e($meta->logo ?? 'https://shefat.info/logo.png'); ?>">
    <meta name="Classification" content="Website">
    <meta name="identifier-URL" content="https://shefat.info">
    <meta name="directory" content="submission">
    <meta name="category" content="Internet">
    <meta name="coverage" content="Worldwide">
    <meta name="distribution" content="Global">
    <meta name="rating" content="General">
    <meta name="target" content="all">
    <meta name="HandheldFriendly" content="True">
    <meta name="author" content="<?php echo e($meta->author ?? 'md shefat ullah masum'); ?>">
    <meta name="developer" content="<?php echo e($meta->developer ?? 'md shefat ullah masum'); ?>">
    <meta name="developer-email" content="<?php echo e($meta->developer_email ?? 'mshefat924@gmail.com"'); ?>">
    <meta name="developer-company" content="<?php echo e($meta->developer_company ?? 'hungry coder'); ?>">
    <meta name="copyright" content="https://shefat.info">
    <meta name="price" content="Call for price - <?php echo e($meta->contact_number ?? '+8801646376015'); ?>">

    <meta name="keywords" content="<?php echo e(($seo->keywords??'') .',
        shefat, shefat ullah, sifat, hungry, hungry-coder, hungry coder, shefat masum,
        shefat-ullah-masum, muhammad shefat ullah masum, web instructor, lws, learn with,
        learn-with-shefat, programming course, programming hero, creative it, md masum, techparkit,
        tech-park-it, techpark it, bangla course, tutorial, shefat tutorial, react, vue, php, laravel,node,
        express, mongo, mongoose, react native, sass, envato, themeforest, web instructor, freelancing,
        Web development services, Custom web development, Front-end development, html course, css course,
        Back-end development, Cross-platform development, Responsive web design, react course, php course,
        Mobile-friendly websites, E-commerce development, Content management systems (CMS), User experience (UX) design,
        Search engine optimization (SEO), Website maintenance and support, Website security, Performance optimization,
        Web application development, API integration, UI/UX design services, Web development agency,
        Professional web development, Full-stack development, Website revamp, Web development consultancy,
    '); ?>">
    <meta name="description" content="<?php echo e($seo->description ?? $des); ?>">

    <title><?php echo e($seo->title ?? 'Md Shefat Masum'); ?></title>
    <meta property="og:title" content="<?php echo e($seo->title ?? 'Md Shefat Masum'); ?>" />
    <meta property="og:site_name" content="<?php echo e($meta->site_name ?? 'Md Shefat Masum'); ?>" />
    <meta property="og:description" content="<?php echo e($seo->description ?? $des); ?>" />
    <meta property="og:type" content="Website" />
    <meta property="og:url" content="<?php echo e(url('')); ?>" />
    <meta property="og:image" content="<?php echo e($seo->image??'https://shefat.info/assets/icons/meta-1200x630.png'); ?>" />
    <meta property="og:image:width" content="1200" />
    <meta property="og:image:height" content="630" />

    <meta name="twitter:title" content="<?php echo e($seo->title ?? 'Md Shefat Masum'); ?>">
    <meta name="twitter:description" content="<?php echo e($seo->description ?? $des); ?>">
    <meta name="twitter:image" content="<?php echo e($seo->image ?? 'https://shefat.info/assets/icons/meta-1200x630.png'); ?>">
    <meta name="twitter:card" content="summary_large_image">

    <?php if(env('APP_ENV') != 'local'): ?>
    <link rel="manifest" href="/manifest.json">
    
    <?php endif; ?>
<?php /**PATH F:\workspace\siyam\personal_website-main\resources\views/frontend/layouts/includes/meta.blade.php ENDPATH**/ ?>