<?php
$meta = [
    // "meta" => [],
    "seo" => [
        "title" => "contact",
        // "image" => "/dummy/small/img-2.jpg",
    ]
];
?>

<?php $__env->startSection('contents'); ?>

<?php echo $__env->make("frontend.layouts.includes.page_banner",[
    "sub_heading" => "Ask Anything",
    "heading" => "Contact Me",
    'page' => "contact"
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section>
    <div class="container">
        <div class="cs_iconbox_wrap">
            <div class="row justify-content-md-center cs_gap_40">
                <div class="col-xl-4 col-md-6">
                    <div class="cs_iconbox cs_style_4 cs_radius_10 d-flex cs_gap_30">
                        <div class="cs_iconbox_icon">
                            <svg width="59" height="68" viewBox="0 0 59 68" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <path fill-rule="evenodd" clip-rule="evenodd"
                                    d="M18.1428 0.551464C17.0099 1.55805 17.8124 4.41003 19.6061 5.80806C21.1165 6.98241 27.5831 7.37386 32.3032 6.64688C45.2365 4.57779 52.3167 8.7719 51.6087 17.9989C50.6174 31.5319 50.4286 41.0944 51.1367 45.6799C51.9391 50.9925 51.8448 50.601 50.3344 49.2589C48.8711 47.9727 45.5197 45.3444 43.6316 43.9464C42.074 42.8279 39.3834 41.2062 38.8642 43.2753C38.0146 46.6865 35.4657 51.9431 33.2 55.5221C28.0551 63.6306 18.1428 65.4761 9.64645 63.7425C6.05913 63.0155 5.96473 61.5616 6.10633 58.3741C6.57835 46.9661 7.23908 16.545 8.37192 10.114C8.93834 6.87057 9.59921 6.31136 11.7233 5.58438C15.4522 4.35411 12.9034 2.22911 8.51366 2.84424C5.44555 3.29161 3.69909 4.63371 2.61345 9.38702C0.961396 16.8245 1.1502 30.3575 0.0173632 58.0385C-0.265847 64.5254 2.94387 66.7623 7.56963 67.3215C10.3073 67.657 14.461 67.7688 21.4469 67.8807C30.132 67.9925 34.4744 68.1603 37.4009 67.657C40.7051 67.0978 42.1685 65.6997 46.0862 62.6241C58.4531 52.7819 57.9809 53.6767 58.0282 40.7029C58.1226 10.9528 54.6297 3.34753 40.3748 2.56463C36.221 2.34095 32.2089 1.78173 30.6984 1.27843C26.7335 -0.00775508 19.2756 -0.455118 18.1428 0.551464ZM26.5446 16.4331C23.0988 16.7686 21.919 19.7884 24.8455 20.739C27.2528 21.5219 39.3363 21.6897 43.3484 21.1864C45.8029 20.8509 44.8116 18.7818 42.8291 17.7752C39.9026 16.2653 33.908 15.7061 26.5446 16.4331ZM20.5973 27.841C12.4786 28.2884 14.6027 30.9167 18.19 31.7555C25.4591 33.4332 44.7644 33.6569 44.7644 31.42C44.7644 28.3443 35.5131 27.0022 20.5973 27.841ZM20.6444 46.5747C23.9957 46.4628 30.6985 45.7918 31.9257 45.3444C34.0498 44.5615 31.1233 41.8773 27.4416 41.2621C22.4854 40.4233 20.4083 40.1996 19.2283 40.3115C12.9977 40.7029 15.7354 46.7424 20.6444 46.5747ZM51.0894 52.8379C50.523 53.3411 45.0948 59.828 38.581 63.0714C36.1265 64.3017 34.852 64.1339 36.4569 61.6734C37.7313 58.9333 42.1212 47.3576 43.2069 47.3576C43.8205 47.4135 51.0894 52.8379 51.0894 52.8379Z"
                                    fill="#342EAD"></path>
                            </svg>
                        </div>
                        <div class="cs_iconbox_info">
                            <h4 class="cs_iconbox_title cs_font_24 cs_semi_bold">My Articles</h4>
                            <p class="cs_iconbox_text">Become an industry expert</p>
                            <a class="cs_accent_color_2 cs_accent_color_hover cs_text_btn" href="blog-details.html">Read
                                Articles</a>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-md-6">
                    <div class="cs_iconbox cs_style_4 cs_radius_10 d-flex cs_gap_30">
                        <div class="cs_iconbox_icon">
                            <svg width="61" height="61" viewBox="0 0 61 61" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M56.2167 24.8988C54.171 25.9977 54.0527 26.2824 54.643 29.4965C56.6103 40.36 46.9707 58.2626 26.5115 53.2987C21.3968 52.0782 20.3736 52.1594 16.3212 54.438C12.1506 56.7571 12.1901 56.7571 12.7409 52.7698C13.4098 47.684 13.331 47.0736 11.5998 44.673C3.18004 33.1586 6.24901 16.4767 18.1705 8.78679C33.8297 -1.34435 46.1443 3.41606 51.7314 15.0526C53.3051 18.3483 54.4068 18.8772 57.9872 18.1449C59.6004 17.8194 59.6004 16.8835 57.9872 14.1575C45.6726 -6.59303 14.6687 -2.36155 4.36042 14.6458C-1.54127 24.3699 -1.69858 37.4306 7.19331 47.7652C8.72777 49.5554 8.88511 51.4678 7.94083 56.5128C6.99656 61.599 8.96384 62.0059 17.0295 58.4253L22.0655 56.1874L25.8033 57.2455C33.3573 59.4019 41.2263 58.3845 48.6624 54.2346C51.7708 52.5256 57.3185 46.0562 59.9939 36.0066C62.2364 27.4217 60.6233 22.5798 56.2167 24.8988Z"
                                    fill="#342EAD"></path>
                                <path fill-rule="evenodd" clip-rule="evenodd"
                                    d="M28.2938 13.0812C23.6356 13.7394 19.2305 16.7774 18.8086 22.9546C18.5048 27.5621 18.5386 27.5958 22.9605 26.7013C26.6904 25.9418 26.4878 26.1444 26.4878 23.309C26.4878 20.8955 27.1629 19.5284 29.0026 18.5833C33.087 16.5073 36.0238 21.9756 36.0238 23.6972C36.0238 25.5875 34.6734 26.5832 30.4203 27.8152C26.9436 28.8279 25.8297 30.2625 25.6946 33.8574C25.6608 34.9208 25.5428 35.7646 25.4246 35.8996C24.9014 36.5409 26.7242 37.1318 28.6651 36.9629C34.4879 36.4397 34.4035 36.4904 34.0827 34.2962C33.8803 32.9292 34.0152 32.7266 35.3992 32.3046C38.741 31.292 40.6481 29.368 41.6608 25.9925C44.3105 17.2837 38.4878 11.6635 28.2938 13.0812ZM33.7453 14.0939C37.5427 14.6508 41.087 19.5622 40.4287 23.3934C39.8211 26.9377 37.897 29.1149 34.0659 30.5494C32.2093 31.2414 31.6186 32.119 31.6018 34.1781V35.3258C29.5428 35.5283 29.4077 35.5283 28.0574 35.7309C28.2938 30.752 27.9562 30.2456 34.1166 28.0853C37.9816 26.7351 38.8254 23.5115 36.3106 19.7647C32.2769 13.7563 21.8972 17.7394 23.8719 24.5411C23.9563 24.8617 24.0069 25.1487 23.9731 25.1824C23.9225 25.233 21.7284 25.7224 21.5596 25.7224C21.5427 25.7224 21.4246 23.6465 21.3233 22.9377C20.4288 16.8449 26.893 13.115 33.7453 14.0939ZM27.3318 38.887C24.2938 40.271 24.1756 43.9839 27.1292 45.0472C33.0195 47.1738 38.3529 43.6802 35.0279 39.8827C34.0491 38.7351 29.0533 38.0937 27.3318 38.887ZM31.6525 39.8997C33.0026 40.1021 34.1841 41.1823 34.1841 42.1949C34.1841 44.0683 29.5934 44.9967 27.9394 43.4608C27.1292 42.7013 26.8593 39.1739 31.6525 39.8997Z"
                                    fill="#342EAD"></path>
                            </svg>
                        </div>
                        <div class="cs_iconbox_info">
                            <h4 class="cs_iconbox_title cs_font_24 cs_semi_bold">FAQ's</h4>
                            <p class="cs_iconbox_text">Become an industry expert</p>
                            <a class="cs_accent_color_2 cs_accent_color_hover cs_text_btn" href="faq.html">Check
                                FAQ’s</a>
                        </div>
                    </div>
                </div>
                <div class="col-xl-4 col-md-6">
                    <div class="cs_iconbox cs_style_4 cs_radius_10 d-flex cs_gap_30">
                        <div class="cs_iconbox_icon">
                            <svg width="63" height="62" viewBox="0 0 63 62" fill="none"
                                xmlns="http://www.w3.org/2000/svg">
                                <path fill-rule="evenodd" clip-rule="evenodd"
                                    d="M21.8927 3.88777C16.7883 8.35151 15.6041 8.94106 10.5814 9.4885C4.04783 10.2044 4.17029 10.1623 4.4153 11.5098C4.66031 12.9416 5.02794 18.3739 5.15045 19.8056C0.250279 25.5748 0.127695 25.3222 0.576877 28.5647C0.740216 29.8701 0.413578 41.998 1.23027 53.2416C1.43445 56.063 2.33277 57.3685 4.86452 58.716C9.76469 61.2427 13.8073 59.7688 9.92799 56.8631C6.45704 54.2523 6.13048 53.1153 5.76297 42.756C5.64046 39.3872 5.35458 34.7971 5.10957 32.5231C4.12954 23.5114 7.11051 27.2593 6.98801 28.0173C6.743 30.0386 7.72299 31.6388 12.0515 33.9549C14.6649 35.3445 24.4243 41.7875 28.3036 43.135C34.0613 45.1984 36.4298 41.4927 49.9869 31.9335C52.4778 30.207 54.1112 28.6489 55.0504 27.1329C57.4188 23.385 57.6639 42.377 55.3363 50.4623C53.7846 55.8525 53.3354 56.0209 38.4307 56.3999C23.1586 56.7789 15.8899 57.7896 16.2574 58.9266C17.1557 61.7059 51.0078 62.3375 56.3571 59.7267C58.7256 58.5476 61.2981 52.5678 61.7881 49.6622C62.5231 45.3669 62.5641 38.7555 61.9107 29.9543C61.4615 23.6377 60.8488 22.2481 57.4596 19.1319C56.2754 18.037 56.1937 15.9735 57.2554 11.8467C57.6637 10.2465 58.1947 7.67774 54.4787 7.67774C50.7627 7.67774 44.8008 7.93039 43.7799 7.93039C42.3099 7.00395 36.2257 3.42454 35.164 2.32966C34.2248 1.57167 28.5079 -1.88141 21.8927 3.88777ZM35.164 6.24596C36.5523 7.1724 37.6956 7.97251 37.6956 8.09885C37.6956 8.18307 34.1838 8.26727 29.8961 8.26727C21.5658 8.26727 21.4026 8.18306 24.3019 6.33019C28.467 3.59298 31.1213 3.59298 35.164 6.24596ZM52.6003 24.101C52.2736 25.7854 50.5177 26.5434 49.3335 25.5748C48.476 24.9011 47.6594 24.7326 44.3518 24.7326C43.3309 24.7326 25.7719 24.6484 17.6866 25.2379C10.5813 25.7433 14.379 28.6489 18.1358 29.1542C21.2801 29.5754 46.5976 28.5647 46.1076 29.3648C45.8626 29.7859 37.8589 35.8498 32.5913 40.2715C31.4887 39.6819 10.9489 28.9016 10.173 28.9016C9.47885 28.9016 8.98891 12.5626 9.02974 12.5205C9.15225 12.352 32.8771 11.6783 52.3552 11.6783C53.0086 17.9107 53.3761 20.0583 52.6003 24.101ZM32.673 17.7422C30.1004 20.3952 32.9179 21.4058 42.3507 21.2374C50.8035 21.069 51.457 20.9005 49.8236 18.9634C48.3944 17.1948 34.1431 16.1841 32.673 17.7422Z"
                                    fill="#342EAD"></path>
                            </svg>
                        </div>
                        <div class="cs_iconbox_info">
                            <h4 class="cs_iconbox_title cs_font_24 cs_semi_bold">Direct email</h4>
                            <p class="cs_iconbox_text">Become an industry expert</p>
                            <a class="cs_accent_color_2 cs_accent_color_hover cs_text_btn" href="contact.html">Send An
                                Email</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="position-relative">
    <div class="cs_service_shape_1 position-absolute">
        <img src="assets/img/service_shape_1.svg" alt="">
    </div>
    <div class="cs_height_115 cs_height_lg_45"></div>
    <div class="container">
        <div class="row">
            <div class="col-lg-8 offset-lg-2">
                <h4 class="cs_form_title cs_font_36 cs_semi_bold m-0">Lets Talk</h4>
                <p class="cs_form_text">Got a project in mind? Fill in the form or send us.</p>
                <div class="cs_height_5 cs_height_lg_5"></div>
                <form action="https://portm-html.vercel.app/post">
                    <input class="form-control" type="text" name="f_name" id="f_name" placeholder="First name"
                        required="">
                    <div class="cs_height_25 cs_height_lg_25"></div>
                    <input class="form-control" type="text" name="l_name" id="l_name" placeholder="Last name"
                        required="">
                    <div class="cs_height_25 cs_height_lg_25"></div>
                    <input class="form-control" type="email" name="email" id="email" placeholder="Email" required="">
                    <div class="cs_height_25 cs_height_lg_25"></div>
                    <select class="form-control cs_select_option" name="budget-range" id="budget-range" required="">
                        <option value="" selected="" disabled="">Select your budget</option>
                        <option value="0-100">$0 - $100</option>
                        <option value="100-200">$100 - $200</option>
                        <option value="200-500">$200 - $500</option>
                        <option value="500-1000">$500 - $1000</option>
                    </select>
                    <div class="cs_height_25 cs_height_lg_25"></div>
                    <textarea class="form-control" name="message" placeholder="Your message" cols="30" rows="5"
                        required=""></textarea>
                    <div class="cs_height_25 cs_height_lg_25"></div>
                    <button type="submit" class="cs_btn cs_style_1 cs_primary_font"><span>Send Message</span></button>
                </form>
            </div>
        </div>
    </div>
    <div class="cs_height_150 cs_height_lg_80"></div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.layout',$meta, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\workspace\siyam\personal_website-main\resources\views/frontend/pages/contact.blade.php ENDPATH**/ ?>