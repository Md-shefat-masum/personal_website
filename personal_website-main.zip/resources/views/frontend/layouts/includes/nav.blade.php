<div class="cs_nav">
    <ul class="cs_nav_list">
        <li class="menu-item-has-children">
            <a href="/">Home</a>
        </li>
        <li class="menu-item-has-children">
            <a href="/about">About</a>
        </li>
        <li class="menu-item-has-children">
            <a href="/portfolio">Portfolio</a>
        </li>
        <li class="menu-item-has-children">
            <a href="/all-courses">All Courses</a>
        </li>
        <li>
            <a href="/contact">Contact</a>
        </li>
    </ul>
</div>
