{!! ($content) !!}
